<?php

if ( ! defined( 'ABSPATH' ) ) exit;

if( !class_exists( 'UT_Word_rotator' ) ) {
	
    class UT_Word_rotator {
        
        private $shortcode;
            
        function __construct() {
			
            /* shortcode base */
            $this->shortcode = 'ut_rotate_words';
            
            add_action( 'init', array( $this, 'ut_map_shortcode' ) );
            add_shortcode( $this->shortcode, array( $this, 'ut_create_shortcode' ) );
            
		}
        
        function ut_map_shortcode( $atts, $content = NULL ) {
            
            if( function_exists( 'vc_map' ) ) {
                                
                vc_map(
                    array(
                        'name'            => esc_html__( 'Word Rotator', 'ut_shortcodes' ),
						'description'     => esc_html__( 'Super simple rotating text.', 'ut_shortcodes' ),
                        'base'            => $this->shortcode,
                        'category'        => 'Information',
                        // 'icon'            => 'ut-vc-module-icon',
                        'icon'            => UT_SHORTCODES_URL . '/admin/img/vc_icons/word-rotator.png',
                        'class'           => 'ut-vc-icon-module ut-information-module', 
                        'content_element' => true,
                        'params'          => array(

                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Effect', 'ut_shortcodes' ),
                                'param_name'        => 'word_effect',
                                'group'             => 'General',
                                'value'             => array(
                                    esc_html__( 'Fade' , 'ut_shortcodes' ) => 'fade',
                                    esc_html__( 'Swap (no transition)', 'ut_shortcodes' ) => 'swap',
                                ),
                            ),
                            array(
                                'type'              => 'textfield',
                                'heading'           => esc_html__( 'Rotation Time', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'value in miliseconds, eg "3000"', 'ut_shortcodes'),
                                'param_name'        => 'timer',
                                'group'             => 'General'
                            ),
                            array(
                                'type'              => 'exploded_textarea',
                                'heading'           => esc_html__( 'Words', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'Each new line will be separate Word.', 'ut_shortcodes'),
                                'admin_label'       => true,
                                'param_name'        => 'content',
                                'group'             => 'General'
                            ),
                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Display', 'ut_shortcodes' ),
                                'param_name'        => 'display',
                                'group'             => 'General',
                                'value'             => array(
                                    esc_html__( 'Inline' , 'ut_shortcodes' ) => 'inline',
                                    esc_html__( 'Block'  , 'ut_shortcodes' ) => 'block',
                                ),
                            ),
                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Wait for Preloader', 'ut_shortcodes' ),
                                'param_name'        => 'wait_for_preloader',
                                'group'             => 'General',
                                'value'             => array(
                                    esc_html__( 'yes, please!' , 'ut_shortcodes' ) => 'true',
                                    esc_html__( 'no, thanks!', 'ut_shortcodes' ) => 'false',
                                ),
                            ),

                            // Font Settings
                            array(
                                'type'       => 'dropdown',
                                'heading'    => esc_html__( 'Element Tag', 'ut-core' ),
                                'param_name' => 'tag',
                                'group'      => 'Font Settings',
                                'value'      => array(
                                    esc_html__( 'span', 'ut-core' ) => 'span',
                                    esc_html__( 'h1', 'ut-core' )   => 'h1',
                                    esc_html__( 'h2', 'ut-core' )   => 'h2',
                                    esc_html__( 'h3', 'ut-core' )   => 'h3',
                                    esc_html__( 'h4', 'ut-core' )   => 'h4',
                                    esc_html__( 'h5', 'ut-core' )   => 'h5',
                                    esc_html__( 'h6', 'ut-core' )   => 'h6',
                                    esc_html__( 'Bold Large Text', 'ut-core' ) => 'div',
                                )
                            ),
                            array(
                                'type'              => 'range_slider',
                                'heading'           => esc_html__( 'Font Size', 'ut_shortcodes' ),
                                'param_name'        => 'font_size',
                                'group'             => 'Font Settings',
                                'edit_field_class'  => 'vc_col-sm-12',
                                'value'             => array(
                                    'min'   => '8',
                                    'max'   => '200',
                                    'step'  => '1',
                                    'unit'  => 'px'
                                ),
                                'dependency' => array(
                                    'element' => 'tag',
                                    'value_not_equal_to' => array('div')
                                ),
                            ),
                            array(
                                'type'              => 'range_slider',
                                'heading'           => esc_html__( 'Large Desktop Font Size', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'Viewport min width 1201px. Also applies to tablet and mobile landscape mode.', 'ut_shortcodes' ),
                                'param_name'        => 'font_size_vw',
                                'group'             => 'Font Settings',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'value'             => array(
                                    'default'   => '0',
                                    'min'       => '0',
                                    'max'       => '20',
                                    'step'      => '0.1',
                                    'unit'      => 'vw',
                                ),
                                'dependency' => array(
                                    'element' => 'tag',
                                    'value' => 'div',
                                ),
                            ),
                            array(
                                'type'              => 'range_slider',
                                'heading'           => esc_html__( 'Tablet and small Desktop Font Size', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'Viewport 768px to 1200px. Only applies to portrait mode.', 'ut_shortcodes' ),
                                'param_name'        => 'font_size_tablet_vh',
                                'group'             => 'Font Settings',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'value'             => array(
                                    'default'   => '4',
                                    'min'       => '0',
                                    'max'       => '20',
                                    'step'      => '0.1',
                                    'unit'      => 'vh',
                                ),
                                'dependency' => array(
                                    'element' => 'tag',
                                    'value' => 'div',
                                ),
                            ),
                            array(
                                'type'              => 'range_slider',
                                'heading'           => esc_html__( 'Mobile Font Size', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'Viewport max width 767px. Only applies to portrait mode.', 'ut_shortcodes' ),
                                'param_name'        => 'font_size_mobile_vh',
                                'group'             => 'Font Settings',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'value'             => array(
                                    'default'   => '4',
                                    'min'       => '0',
                                    'max'       => '20',
                                    'step'      => '0.1',
                                    'unit'      => 'vh',
                                ),
                                'dependency' => array(
                                    'element' => 'tag',
                                    'value' => 'div',
                                ),
                            ),
                            array(
                                'type'              => 'range_slider',
                                'heading'           => esc_html__( 'Line Height', 'ut_shortcodes' ),
                                'param_name'        => 'line_height',
                                'group'             => 'Font Settings',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'value'             => array(
                                    'default'   => '100',
                                    'min'       => '80',
                                    'max'       => '300',
                                    'step'      => '5',
                                    'unit'      => '%'
                                ),
                            ),
                            array(
                                'type'              => 'range_slider',
                                'heading'           => esc_html__( 'Letter Spacing', 'ut_shortcodes' ),
                                'param_name'        => 'letter_spacing',
                                'group'             => 'Font Settings',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'value'             => array(
                                    'default'   => '0',
                                    'min'       => '-0.2',
                                    'max'       => '0.2',
                                    'step'      => '0.01',
                                    'unit'      => 'em'
                                ),
                            ),
                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Font Weight', 'ut_shortcodes' ),
                                'param_name'        => 'font_weight',
                                'group'             => 'Font Settings',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'value'             => array(
                                    esc_html__( 'Select Font Weight' , 'ut_shortcodes' ) => '',
                                    esc_html__( 'lighter' , 'ut_shortcodes' )  => 'lighter',
                                    esc_html__( 'normal' , 'ut_shortcodes' ) => 'normal',
                                    esc_html__( 'bold' , 'ut_shortcodes' )   => 'bold',
                                    esc_html__( 'bolder' , 'ut_shortcodes' ) => 'bolder',
                                    esc_html__( '100' , 'ut_shortcodes' )    => '100',
                                    esc_html__( '200' , 'ut_shortcodes' )    => '200',
                                    esc_html__( '300' , 'ut_shortcodes' )    => '300',
                                    esc_html__( '400' , 'ut_shortcodes' )    => '400',
                                    esc_html__( '500' , 'ut_shortcodes' )    => '500',
                                    esc_html__( '600' , 'ut_shortcodes' )    => '600',
                                    esc_html__( '700' , 'ut_shortcodes' )    => '700',
                                    esc_html__( '800' , 'ut_shortcodes' )    => '800',
                                    esc_html__( '900' , 'ut_shortcodes' )    => '900',
                                ),
                            ),
                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Font Style', 'ut_shortcodes' ),
                                'param_name'        => 'font_style',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'group'             => 'Font Settings',
                                'value'             => array(
                                    esc_html__( 'Select Font Style' , 'ut_shortcodes' ) => '',
                                    esc_html__( 'normal' , 'ut_shortcodes' ) => 'normal',
                                    esc_html__( 'italic' , 'ut_shortcodes' ) => 'italic',
                                ),
                            ),
                            array(
                                'type'       => 'dropdown',
                                'heading'    => esc_html__( 'Title Text Transform', 'ut-core' ),
                                'param_name' => 'text_transform',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'group'      => 'Font Settings',
                                'value'      => array(
                                    esc_html__( 'Select Text Transform', 'ut-core' ) => '',
                                    esc_html__( 'none', 'ut-core' )                  => 'none',
                                    esc_html__( 'capitalize', 'ut-core' )            => 'capitalize',
                                    esc_html__( 'uppercase', 'ut-core' )             => 'uppercase',
                                    esc_html__( 'lowercase', 'ut-core' )             => 'lowercase'
                                ),
                            ),
                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Text Align', 'ut_shortcodes' ),
                                'param_name'        => 'text_align',
                                'edit_field_class'  => 'vc_col-sm-4',
                                'group'             => 'Font Settings',
                                'value'             => array(
                                    esc_html__( 'left' , 'ut_shortcodes' ) => 'left',
                                    esc_html__( 'center' , 'ut_shortcodes' ) => 'center',
                                    esc_html__( 'right' , 'ut_shortcodes' ) => 'right',
                                ),
                            ),
                            array(
								'type'              => 'colorpicker',
								'heading'           => esc_html__( 'Font Color', 'ut_shortcodes' ),
								'param_name'        => 'font_color',
								'group'             => 'Font Settings'
						  	),

                            // Text Effects
                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Activate Glow Effect?', 'ut-core' ),
                                'param_name'        => 'glow_effect',
                                'group'             => 'Text Effects',
                                'value'             => array(
                                    esc_html__( 'no', 'ut-core' )  => 'no',
                                    esc_html__( 'yes', 'ut-core' ) => 'yes'
                                )
                            ),
                            array(
                                'type'              => 'colorpicker',
                                'heading'           => esc_html__( 'Glow Color', 'ut-core' ),
                                'param_name'        => 'glow_color',
                                'group'             => 'Text Effects',
                                'dependency'        => array(
                                    'element' => 'glow_effect',
                                    'value'   => array('yes'),
                                )
                            ),
                            array(
                                'type'       => 'dropdown',
                                'heading'    => esc_html__( 'Activate Text Stroke?', 'ut-core' ),
                                'param_name' => 'stroke_effect',
                                'group'      => 'Text Effects',
                                'value'      => array(
                                    esc_html__( 'no', 'ut-core' )  => 'no',
                                    esc_html__( 'yes', 'ut-core' ) => 'yes'
                                )
                            ),
                            array(
                                'type'       => 'colorpicker',
                                'heading'    => esc_html__( 'Stroke Color', 'ut-core' ),
                                'param_name' => 'stroke_color',
                                'group'      => 'Text Effects',
                                'dependency' => array(
                                    'element' => 'stroke_effect',
                                    'value'   => array( 'yes' ),
                                )
                            ),
                            array(
                                'type'       => 'range_slider',
                                'heading'    => esc_html__( 'Stroke Width', 'ut-core' ),
                                'param_name' => 'stroke_width',
                                'group'      => 'Text Effects',
                                'value'      => array(
                                    'default' => '1',
                                    'min'     => '1',
                                    'max'     => '20',
                                    'step'    => '1',
                                    'unit'    => 'px'
                                ),
                                'dependency' => array(
                                    'element' => 'stroke_effect',
                                    'value'   => array( 'yes' ),
                                )
                            ),

                            /* Animation Effect */
                            array(
                                'type'              => 'animation_style',
                                'heading'           => __( 'Animation Effect', 'ut_shortcodes' ),
                                'description'       => __( 'Select image animation effect.', 'ut_shortcodes' ),
                                'group'             => 'Animation',
                                'param_name'        => 'effect',
                                'settings' => array(
                                    'type' => array(
                                        'in',
                                        'out',
                                        'other',
                                    ),
                                )

                            ),

                            array(
                                'type'              => 'textfield',
                                'heading'           => esc_html__( 'Animation Duration', 'unitedthemes' ),
                                'description'       => esc_html__( 'Animation time in seconds  e.g. 1s', 'unitedthemes' ),
                                'param_name'        => 'animation_duration',
                                'group'             => 'Animation',
                            ),

                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Animate Once?', 'unitedthemes' ),
                                'description'       => esc_html__( 'Animate only once when reaching the viewport, animate everytime when reaching the viewport or make the animation infinite? By default the animation executes everytime when the element becomes visible in viewport, means when leaving the viewport the animation will be reseted and starts again when reaching the viewport again. By setting this option to yes, the animation executes exactly once. By setting it to infinite, the animation loops all the time, no matter if the element is in viewport or not.', 'unitedthemes' ),
                                'param_name'        => 'animate_once',
                                'group'             => 'Animation',
                                'value'             => array(
                                    esc_html__( 'yes', 'unitedthemes' )      => 'yes',
                                    esc_html__( 'no' , 'unitedthemes' )      => 'no',
                                    esc_html__( 'infinite', 'unitedthemes' ) => 'infinite',
                                )
                            ),

                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Animate Image on Tablet?', 'ut_shortcodes' ),
                                'param_name'        => 'animate_tablet',
                                'group'             => 'Animation',
                                'edit_field_class'  => 'vc_col-sm-6',
                                'value'             => array(
                                    esc_html__( 'no', 'ut_shortcodes' ) => 'false',
                                    esc_html__( 'yes'  , 'ut_shortcodes' ) => 'true'
                                ),
                            ),

                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Animate Image on Mobile?', 'ut_shortcodes' ),
                                'param_name'        => 'animate_mobile',
                                'group'             => 'Animation',
                                'edit_field_class'  => 'vc_col-sm-6',
                                'value'             => array(
                                    esc_html__( 'no', 'ut_shortcodes' ) => 'false',
                                    esc_html__( 'yes'  , 'ut_shortcodes' ) => 'true'
                                ),
                            ),

                            array(
                                'type'              => 'dropdown',
                                'heading'           => esc_html__( 'Delay Animation?', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'Time in milliseconds until the image appears. e.g. 200', 'ut_shortcodes' ),
                                'param_name'        => 'delay',
                                'group'             => 'Animation',
                                'edit_field_class'  => 'vc_col-sm-6',
                                'value'             => array(
                                    esc_html__( 'no', 'ut_shortcodes' ) => 'false',
                                    esc_html__( 'yes'  , 'ut_shortcodes' ) => 'true'
                                )
                            ),

                            array(
                                'type'              => 'textfield',
                                'heading'           => esc_html__( 'Delay Timer', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'Time in milliseconds until the next image appears. e.g. 200', 'ut_shortcodes' ),
                                'param_name'        => 'delay_timer',
                                'group'             => 'Animation',
                                'edit_field_class'  => 'vc_col-sm-6',
                                'dependency'        => array(
                                    'element' => 'delay',
                                    'value'   => 'true',
                                )
                            ),

                            array(
                                'type'              => 'textfield',
                                'heading'           => esc_html__( 'CSS Class', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ut_shortcodes' ),
                                'param_name'        => 'class',
                                'group'             => 'General'
                            ),
                            array(
                                'type'              => 'css_editor',
                                'param_name'        => 'css',
                                'group'             => esc_html__( 'Design Options', 'ut_shortcodes' ),
                            ),


                        )                        
                        
                    )
                
                ); /* end mapping */
                
            } 
        
        }
        
        function ut_create_shortcode( $atts, $content = NULL ) {

            /**
             * @var string $word_effect
             * @var string $timer
             * @var string $type
             * @var string $display_cursor
             * @var string $font_source
             * @var string $google_fonts
             * @var string $websafe_fonts
             * @var string $custom_fonts
             * @var string $tag
             * @var string $font_size
             * @var string $font_size_vw
             * @var string $font_size_tablet_vh
             * @var string $font_size_mobile_vh
             * @var string $text_align
             * @var string $font_color
             * @var string $text_transform
             * @var number $line_height
             * @var number $letter_spacing
             * @var string $glow_color
             * @var string $stroke_effect
             * @var string $stroke_color
             * @var string $stroke_width
             * @var string $display
             * @var string $wait_for_preloader
             * @var string $css
             * @var string $class
             */

            extract( shortcode_atts( array (
                'word_effect'         => 'fade',
                'timer'               => 2000,
                'tag'                 => 'span',
                'font_size'           => '',
                'font_size_vw'        => '',
                'font_size_tablet_vh' => '4',
                'font_size_mobile_vh' => '4',
                'line_height'         => '100',
                'letter_spacing'      => '',
                'font_weight'         => '',
                'text_transform'      => '',
                'text_align'          => '',
                'font_style'          => '',
                'font_color'          => '',
                'glow_effect'         => '',
                'glow_color'          => '',
                'stroke_effect'       => '',
                'stroke_color'        => '#000',
                'stroke_width'        => '1',
                'display'             => '',

                // Animation
                'effect'              => '',
                'animate_once'        => 'yes',
                'animate_tablet'      => 'no',
                'animate_mobile'      => 'no',
                'delay'               => 'no',
                'delay_timer'         => '100',
                'animation_duration'  => '',
                'animation_between'   => '',

                // Wait for Preloader
                'wait_for_preloader'  => 'true',

                'css'               => '',
                'class'             => ''

            ), $atts ) ); 
            
            $classes    = array();
            $classes[]  = $class;

            if( $tag == 'div' ) {

                $classes[] = 'ut-skip-flowtype';

            }

            // animation attributes
            $attributes = array();

            // animation effect
            $dataeffect = NULL;
            $outer_classes = array( apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, '' ), $this->shortcode, $atts ) );

            if( !empty( $effect ) && $effect != 'none' ) {

                $attributes['data-effect']      = esc_attr( $effect );
                $attributes['data-animateonce'] = esc_attr( $animate_once );
                $attributes['data-delay'] = $delay == 'true' ? esc_attr( $delay_timer ) : 0;

                if( $animate_once == 'infinite' && !empty( $animation_between ) ) {

                    if( strpos($animation_between, 's') === true ) {
                        $animation_between = str_replace('s' , '', $animation_between);
                    }

                    $attributes['data-animation-between'] = esc_attr( $animation_between );

                }

                if( !empty( $animation_duration ) ) {

                    $attributes['data-animation-duration'] = esc_attr( ut_add_timer_unit( $animation_duration, 's' ) );

                }

                $outer_classes[]  = 'ut-animate-element';
                $outer_classes[]  = 'animated';

                if( $animate_tablet ) {
                    $outer_classes[]  = 'ut-no-animation-tablet';
                }

                if( $animate_mobile ) {
                    $outer_classes[]  = 'ut-no-animation-mobile';
                }

                if( $animate_once == 'infinite' && empty( $animation_between ) ) {
                    $outer_classes[]  = 'infinite';
                }

            }

            $attributes = implode(' ', array_map(
                function ($v, $k) { return sprintf("%s=\"%s\"", $k, $v); },
                $attributes,
                array_keys( $attributes )
            ) );

            /* split up words */
            $words = explode( ',' , str_replace(',<br />' , ',' , $content) );
			
            /* final rotator word variable*/
            $rotator_words = array();
            
            /* loop through word array and concatinate final string*/
            foreach( $words as $key => $word ) {                
                
				$rotator_words[] = json_encode( $word ); 
				
            }

            /* cut of last comma */ 
            $rotator_words = implode( ",", $rotator_words );
            			
            /* unique ID */
            $id = uniqid("ut_word_rotator_");
            
            $css = '';
            
            // Design Options Gradient
            $vc_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, '.' ), $this->shortcode, $atts );
            $css .= ut_add_gradient_css( $vc_class, $atts );

            if( $tag != 'ut-bold' && $font_size ) {

                if( is_numeric( $font_size ) ) {

                    $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { font-size: ' . $font_size . 'px; }';

                } else {

                    $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { font-size: ' . $font_size . '; }';

                }

            }

            if( $tag == 'div' && $font_size_vw ) {

                $css .= '@media (min-width: 1025px) { #' . $id . ' ' . $tag . '.ut-word-rotator { font-size: ' . $font_size_vw . 'vw; } }';
                $css .= '@media (max-width: 1200px) and (orientation: landscape) { #' . $id . ' ' . $tag . '.ut-word-rotator { font-size: ' . $font_size_vw . 'vw; } }';

            }

            if( $tag == 'div' && $font_size_tablet_vh ) {

                $css .= '@media (min-width: 768px) and (max-width: 1024px) and (orientation: portrait) { #' . $id . ' ' . $tag . '.ut-word-rotator { font-size: ' . $font_size_tablet_vh . 'vh; } }';

            }

            if( $tag == 'div' && $font_size_mobile_vh ) {

                $css .= '@media (max-width: 767px) and (orientation: portrait) { #' . $id . ' ' . $tag . '.ut-word-rotator { font-size: ' . $font_size_mobile_vh . 'vh; } }';

            }

            if( $line_height ) {
                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { line-height: ' . $line_height . '%; }';
            }

            if( $letter_spacing ) {
                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { letter-spacing: ' . $letter_spacing . 'em; }';
            }

            if( $font_weight ) {
                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { font-weight: ' . $font_weight . '; }';
            }

            if( $font_style ) {
                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { font-style: ' . $font_style . '; }';
            }

            if( $text_transform ) {
                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { text-transform: ' . $text_transform . '; }';
            }

            if( $text_align ) {
                $css .= '#' . $id . ' { text-align: ' . $text_align . '; }';
            }

            if( $font_color ) {
                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { color: ' . $font_color . ' !important; }';
            }
            
            if( $display ) {
                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { display: ' . $display . '; }';
            }

            if( $glow_color ) {

                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator { 
                        -webkit-text-shadow: 0 0 20px ' . $glow_color . ',  2px 2px 3px black;
                           -moz-text-shadow: 0 0 20px ' . $glow_color . ',  2px 2px 3px black;
                                text-shadow: 0 0 20px ' . $glow_color . ',  2px 2px 3px black; 
                }';

            }

            if( $stroke_effect == 'yes' ) {

                $css .= '#' . $id . ' ' . $tag . '.ut-word-rotator {
                    -moz-text-stroke-color: ' . $stroke_color .';
                    -webkit-text-stroke-color: ' . $stroke_color .';
                    -moz-text-stroke-width: ' . $stroke_width .'px;  
                    -webkit-text-stroke-width: ' . $stroke_width .'px;	            
	            }';

            }

			ob_start(); ?>
			
			<script type="text/javascript">
				
				/* <![CDATA[ */
				(function($){

					"use strict";
					
					var ut_rotator_words = [<?php echo $rotator_words; ?>],
                        wait_for_preloader = <?php echo $wait_for_preloader; ?>,
						counter = 0;
					
					// check if word rotator is located inside 3image fader
					if( $("#<?php echo $id; ?>").closest("#ut-hero").length && $("#<?php echo $id; ?>").closest("#ut-hero").hasClass("ut-hero-imagefader-background") ) {
					   
						$("ul.ut-image-fader li", "#ut-hero").on("webkitAnimationStart mozAnimationStart MSAnimationStart oanimationstart animationstart", function(){

							var indx = $(this).index();

							if( counter > 0 ) {

								$("#<?php echo $id; ?> .ut-word-rotator").fadeOut(726, function(){

									$("#<?php echo $id; ?> .ut-word-rotator").html(ut_rotator_words[indx]).fadeIn(726);

								});								
								
							}
							
							counter++;

						});

						$("ul.ut-image-fader li", "#ut-hero").on("animationiteration", function(){

							var indx = $(this).index();
							
							$("#<?php echo $id; ?> .ut-word-rotator").fadeOut(726,function(){

								$("#<?php echo $id; ?> .ut-word-rotator").html(ut_rotator_words[indx]).fadeIn(726);

							});

						});							
					   
					} else {
						
						var ut_word_rotator = function() {

						    <?php

                            $effect_timer = ( $timer <= 400 ) ? $timer / 2 : 400;
                            $effect_timer = $word_effect == 'fade' ? $effect_timer : 0;

                            ?>

							setInterval( function() {

                                $("#<?php echo $id; ?> .ut-word-rotator").fadeOut( <?php echo $effect_timer; ?>, function() {

                                    $(this).html(ut_rotator_words[counter=(counter+1)%ut_rotator_words.length]).fadeIn( <?php echo $effect_timer; ?> );

                                });

							}, <?php echo $timer; ?>);

						};
						
						if( typeof preloader_settings != "undefined" && wait_for_preloader === 'true'  ) {

							var <?php echo $id; ?>_check_loader_status = setInterval( function() {

								if( !preloader_settings.loader_active ) {

									ut_word_rotator();
									clearInterval(<?php echo $id; ?>_check_loader_status);

								}

							}, 50 );

						} else {

							ut_word_rotator();

						}
						
					}

				})(jQuery);
            
            /* ]]> */
            </script>

			<?php 

			$script = ob_get_clean();
           
            /* start output */
            $output = '';
            
            /* attach css */
            if( !empty( $css ) ) {
                $output .= ut_minify_inline_css( '<style type="text/css">' . $css . '</style>' );
            }

            $content = '<' . $tag . ' class="' . implode( ' ', $classes ) . ' ut-word-rotator">' . $words[0] . '</' . $tag . '>';
                
            return $output . '<div id="' . $id . '" class="ut-word-rotator-wrap wpb_content_element ' . implode( ' ', $outer_classes ) . '" ' . $attributes . '>' . $content . '</div>' . $script;
            
        
        }
            
    }

}

new UT_Word_rotator;