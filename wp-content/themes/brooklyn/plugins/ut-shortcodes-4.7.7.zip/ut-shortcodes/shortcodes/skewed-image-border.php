<?php

if ( ! defined( 'ABSPATH' ) ) exit;

if( !class_exists( 'UT_Skewed_Image_Border' ) ) {

    class UT_Skewed_Image_Border {

        private $shortcode;

        function __construct() {

            /* shortcode base */
            $this->shortcode = 'ut_skewed_image_border';

            add_action( 'init', array( $this, 'ut_map_shortcode' ) );
            add_shortcode( $this->shortcode, array( $this, 'ut_create_shortcode' ) );

        }

        function ut_map_shortcode( $atts, $content = NULL ) {

            if( function_exists( 'vc_map' ) ) {

                vc_map(
                    array(
                        'name' => esc_html__('Skewed Images', 'ut_shortcodes'),
                        'description' => esc_html__('A visual border consisting of up to 8 images.', 'ut_shortcodes'),
                        'base' => $this->shortcode,
                        'category' => 'Media',
                        'icon' => UT_SHORTCODES_URL . '/admin/img/vc_icons/image-gallery.png',
                        'class' => 'ut-vc-icon-module ut-media-module',
                        'content_element' => true,
                        'params' => array(

                            array(
                                'type'              => 'attach_images',
                                'heading'           => esc_html__( 'Border Images', 'ut_shortcodes' ),
                                'description'       => esc_html__( 'Only supports a maximum of 8 Images.', 'ut_shortcodes' ),
                                'param_name'        => 'gallery',
                                'admin_label'       => true
                            ),

                        )
                    )
                );

            }

        }

        function create_placeholder_svg( $width , $height ){

            // fallback values
            $width = empty( $width ) ? '800' : $width;
            $height = empty( $height ) ? '600' : $height;

            return 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D\'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg\' viewBox%3D\'0 0 ' . esc_attr( $width ) . ' ' . esc_attr( $height ) . '\'%2F%3E';

        }


        function ut_create_shortcode( $atts, $content = NULL ) {

            /**
             * @var $gallery
             * @var $class
             * @var $css
             */
            extract( shortcode_atts( array (
                'gallery'   =>  '',
                'class'     =>  '',
                'css'       =>  '',
            ), $atts ) );

            $classes = array( $class );


            $gallery = explode( ',' , $gallery );

            $image_sizes = count( $gallery ) > 4 ? array( 800, 600 ) : array( 1600, 900 );

            // start output
            $output = '';

            if( !empty( $gallery ) && is_array( $gallery ) ) {

                $gallery = array_slice( $gallery, 0, 8 );

                $output .= '<div class="ut-skewed-image-border">';

                foreach( $gallery as $image ) {

                    $thumbnail = wp_get_attachment_image_src( $image, 'full' );
                    $thumbnail = ut_resize( $thumbnail[0], $image_sizes[0], $image_sizes[1], true, true, true );

                    $output .= '<div class="ut-skewed-image-border-slice">';

                        $output .= '<img class="ut-lazy" src="' . $this->create_placeholder_svg( $image_sizes[0], $image_sizes[1] ) . '" data-src="' . $thumbnail . '">';

                    $output .= '</div>';

                }

                $output .= '</div>';

            }

            return $output;


        }

    }

}

new UT_Skewed_Image_Border;


if ( class_exists( 'WPBakeryShortCode' ) ) {

    class WPBakeryShortCode_ut_skewed_image_border extends WPBakeryShortCode {

        /* add images to visual composer */
        public function singleParamHtmlHolder( $param, $value ) {

            $output = '';

            $param_name = isset( $param['param_name'] ) ? $param['param_name'] : '';

            if ( 'gallery' === $param_name ) {

                $images_ids = empty( $value ) ? array() : explode( ',', trim( $value ) );
                $output .= '<ul class="attachment-thumbnails' . ( empty( $images_ids ) ? ' image-exists' : '' ) . '" data-name="' . $param_name . '">';
                foreach ( $images_ids as $image ) {
                    $img = wpb_getImageBySize( array( 'attach_id' => (int) $image, 'thumb_size' => 'thumbnail' ) );
                    $output .= ( $img ? '<li>' . $img['thumbnail'] . '</li>' : '<li><img width="150" height="150" test="' . $image . '" src="' . vc_asset_url( 'vc/blank.gif' ) . '" class="attachment-thumbnail" alt="" title="" /></li>' );
                }
                $output .= '</ul>';
                $output .= '<a href="#" class="column_edit_trigger' . ( ! empty( $images_ids ) ? ' image-exists' : '' ) . '">' . __( 'Add images', 'js_composer' ) . '</a>';

            }

            return $output;

        }

    }

}